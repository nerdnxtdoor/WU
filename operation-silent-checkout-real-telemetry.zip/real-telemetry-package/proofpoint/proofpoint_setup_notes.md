# Proofpoint Setup Notes

Goal: capture real phishing delivery, URL rewrite, click, and user-reporting events.

Recommended setup:

- Use an approved simulation sender.
- Send the email template to the dedicated lab user.
- Replace `https://training.example.invalid/silent-checkout` with your controlled training URL.
- Confirm URL defense rewrites the link, if URL defense is enabled.
- Have the lab user click the link.
- Optionally have the user report the message using your phishing report workflow.

Expected events:

- Message trace / delivery event.
- URL click event.
- Sender, recipient, subject, URL metadata.
- Campaign or threat classification, depending on policy.
- User-reported phishing event, if reported.

