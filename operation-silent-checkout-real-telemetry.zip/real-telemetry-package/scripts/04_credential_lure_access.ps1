<#
Searches and reads fake credential lure files only.
Does not access LSASS, browser stores, password vaults, DPAPI, or real secrets.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$CredDir = Join-Path $Root "credential_lures"
$OutDir = Join-Path $Root "credential_lure_results"

if (-not (Test-Path $CredDir)) {
    throw "Credential lure directory not found. Run 00_prepare_lab.ps1 first."
}

New-TrainingDirectory -Path $OutDir

Write-TrainingStatus "Searching fake credential lure files."

Get-ChildItem -Path $Root -Recurse -File -Include "*password*", "*credential*", "*vault*", "*secret*" |
    Select-Object FullName, Length, LastWriteTime |
    Format-Table -AutoSize | Out-File -FilePath (Join-Path $OutDir "credential_named_files_found.txt") -Encoding utf8

Get-Content -Path (Join-Path $CredDir "browser_passwords_backup.txt") |
    Out-File -FilePath (Join-Path $OutDir "browser_passwords_backup_readback.txt") -Encoding utf8

Get-Content -Path (Join-Path $CredDir "fake_vault_export.csv") |
    Out-File -FilePath (Join-Path $OutDir "fake_vault_export_readback.txt") -Encoding utf8

Write-TrainingStatus "Credential lure access complete. Only fake training files were read."

