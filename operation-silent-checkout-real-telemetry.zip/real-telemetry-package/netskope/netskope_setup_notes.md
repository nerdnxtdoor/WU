# Netskope Setup Notes

Goal: capture real web, SaaS, download, and upload activity.

Recommended exercise controls:

- Route the test workstation through Netskope.
- Allow access to the controlled training site.
- Monitor or coach policy for the payload download.
- Create a policy for upload attempts to the approved lab destination.
- Optionally create a DLP profile matching fake strings such as `FAKE-125000` or `000-00-0000`.

Expected events:

- Visit to training portal.
- Download of `Payroll_Update_Q3.zip`.
- Access to AWS console, if browser-based.
- Upload of `finance_review_backup.zip`.
- DLP/policy action for fake finance data, if configured.

