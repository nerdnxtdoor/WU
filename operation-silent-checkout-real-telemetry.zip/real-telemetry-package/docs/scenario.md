# Scenario: Operation Silent Checkout

Northstar Market is preparing Q3 payroll and executive bonus forecasts. A finance analyst receives a payroll-themed phishing email that links to a controlled training portal. The user downloads and runs a benign payroll updater from a managed Windows test workstation.

The simulated actor then performs non-destructive activity that should appear in real security tooling:

1. Phishing email delivery and link click.
2. Browser access and file download.
3. PowerShell execution from a user context.
4. Local host and user discovery.
5. Clearly named persistence simulation.
6. Fake credential lure file discovery and access.
7. Okta login and AWS app launch.
8. Read-only AWS discovery.
9. Fake finance data staging and compression.
10. Controlled upload attempt to an approved lab destination.
11. Harmless impact note creation.

## Primary Test User

Use a dedicated lab identity, for example:

```text
jane.reed@northstarmarket.example
```

## Primary Test Host

Use a disposable Windows machine enrolled in Falcon and routed through Netskope, for example:

```text
FIN-WS-014
```

## Expected Investigation Conclusion

The user received and clicked a payroll-themed phishing email. The click led to a controlled download and benign script execution. The endpoint then generated real telemetry for discovery, persistence simulation, fake credential lure access, AWS discovery, staging, controlled exfiltration attempt, and an impact note. No real sensitive data was accessed or damaged.

