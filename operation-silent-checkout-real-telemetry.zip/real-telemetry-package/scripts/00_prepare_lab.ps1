<#
Northstar Market SOC simulation.
Prepares fake files used by later phases. Does not touch real user data.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config

$Dirs = @(
    $Root,
    (Join-Path $Root "downloads"),
    (Join-Path $Root "finance_share"),
    (Join-Path $Root "credential_lures"),
    (Join-Path $Root "payload"),
    (Join-Path $Root "staging")
)

foreach ($Dir in $Dirs) {
    New-TrainingDirectory -Path $Dir
}

$FinanceDir = Join-Path $Root "finance_share"
"Employee,Quarter,Amount`nAvery Cole,Q3,72000`nMorgan Lee,Q3,69000" |
    Out-File -FilePath (Join-Path $FinanceDir "Payroll_Q3_Forecast.csv") -Encoding utf8
"Executive,Plan,Bonus`nTaylor Quinn,Retention,FAKE-125000" |
    Out-File -FilePath (Join-Path $FinanceDir "Executive_Bonus_Planning.csv") -Encoding utf8
"Vendor,Settlement,Amount`nContoso Foods,Pending,FAKE-88000`nNorthwind Freight,Pending,FAKE-41000" |
    Out-File -FilePath (Join-Path $FinanceDir "Vendor_Settlement_Report.csv") -Encoding utf8
"employee_id,name,ssn_placeholder`n1001,Avery Cole,000-00-0000`n1002,Morgan Lee,000-00-0000" |
    Out-File -FilePath (Join-Path $FinanceDir "Employee_PII_SAMPLE.csv") -Encoding utf8

$CredDir = Join-Path $Root "credential_lures"
"username,password,system`nFAKE\alice,NotARealPassword!,training-portal" |
    Out-File -FilePath (Join-Path $CredDir "browser_passwords_backup.txt") -Encoding utf8
"client_id,client_secret,scope`ntraining-client,FAKE-SECRET-DO-NOT-USE,read-only" |
    Out-File -FilePath (Join-Path $CredDir "fake_vault_export.csv") -Encoding utf8

$PayloadDir = Join-Path $Root "payload"
$UpdaterPath = Join-Path $PayloadDir "Payroll_Update_Q3.ps1"
@'
[CmdletBinding()]
param()

$Root = "C:\ProgramData\NorthstarTraining"
New-Item -ItemType Directory -Force -Path $Root | Out-Null
Write-Host "Payroll update validation complete."
whoami | Out-Null
hostname | Out-Null
'@ | Out-File -FilePath $UpdaterPath -Encoding utf8

Write-TrainingStatus "Prepared fake data and benign payload under $Root."
Write-TrainingStatus "Use the web folder to host a download page, or zip the payload for your controlled training portal."

