<#
Runs benign discovery commands that resemble common attacker discovery.
Output files are command results, not synthetic log records.
#>
[CmdletBinding()]
param(
    [switch]$IncludeDomainChecks
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$OutDir = Join-Path $Root "discovery_results"
New-TrainingDirectory -Path $OutDir

Write-TrainingStatus "Running local discovery commands."

whoami | Out-File -FilePath (Join-Path $OutDir "whoami.txt") -Encoding utf8
hostname | Out-File -FilePath (Join-Path $OutDir "hostname.txt") -Encoding utf8
ipconfig /all | Out-File -FilePath (Join-Path $OutDir "ipconfig_all.txt") -Encoding utf8
net user | Out-File -FilePath (Join-Path $OutDir "net_user_local.txt") -Encoding utf8
net localgroup administrators | Out-File -FilePath (Join-Path $OutDir "local_admins.txt") -Encoding utf8
qwinsta | Out-File -FilePath (Join-Path $OutDir "sessions.txt") -Encoding utf8
Get-Process | Select-Object -First 40 Name, Id, Path |
    Format-Table -AutoSize | Out-File -FilePath (Join-Path $OutDir "process_sample.txt") -Encoding utf8
Get-ChildItem -Path $Root -Recurse -File |
    Select-Object FullName, Length, LastWriteTime |
    Format-Table -AutoSize | Out-File -FilePath (Join-Path $OutDir "training_file_inventory.txt") -Encoding utf8

if ($IncludeDomainChecks) {
    cmd.exe /c "nltest /domain_trusts" | Out-File -FilePath (Join-Path $OutDir "nltest_domain_trusts.txt") -Encoding utf8
    cmd.exe /c "net group `"Domain Admins`" /domain" | Out-File -FilePath (Join-Path $OutDir "domain_admins_query.txt") -Encoding utf8
}

Write-TrainingStatus "Discovery complete. Results written under $OutDir."

