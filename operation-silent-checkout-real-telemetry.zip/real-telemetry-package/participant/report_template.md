# Incident Report Template

## Executive Summary

## Initial Access

## Affected User And Host

## Timeline

## Endpoint Findings

## Email And Web Findings

## Identity Findings

## Cloud Findings

## Data Staging Or Exfiltration Assessment

## Containment Recommendations

## Eradication And Recovery

## Detection Improvements

## Open Questions

