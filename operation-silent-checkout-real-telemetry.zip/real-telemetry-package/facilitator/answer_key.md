# Facilitator Answer Key

Expected answer:

The lab user received a payroll-themed phishing email, clicked a controlled training URL, downloaded a benign payroll updater, and executed it from the test workstation. Endpoint telemetry should show PowerShell execution, local discovery, scheduled task and Run key creation, fake credential lure access, finance-data staging, upload attempt, and impact-note creation. Okta should show user login/MFA/app-launch activity. AWS CloudTrail should show read-only discovery. Netskope should show web access, download, and upload telemetry. Proofpoint should show email delivery and URL click details.

Key artifacts:

- `C:\ProgramData\NorthstarTraining`
- Scheduled task: `NorthstarPayrollUpdater`
- HKCU Run key: `NorthstarPayrollUpdater`
- Archive: `finance_review_backup.zip`
- Impact note: `READ_ME_TRAINING.txt`

Key safety point:

All data is fake. No credential stores are accessed. No files outside the training root are modified except the optional scheduled task and HKCU Run key.

