<#
Simulates a user executing a downloaded payroll updater.
Generates real process and file telemetry without malicious behavior.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$Payload = Join-Path $Root "payload\Payroll_Update_Q3.ps1"

if (-not (Test-Path $Payload)) {
    throw "Payload not found. Run 00_prepare_lab.ps1 first."
}

Write-TrainingStatus "Launching benign payroll updater through powershell.exe."
$Args = "-NoProfile -ExecutionPolicy Bypass -File `"$Payload`""
Start-Process -FilePath "powershell.exe" -ArgumentList $Args -Wait

Write-TrainingStatus "Initial execution complete."

