@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Payroll_Update_Q3.ps1"
endlocal

