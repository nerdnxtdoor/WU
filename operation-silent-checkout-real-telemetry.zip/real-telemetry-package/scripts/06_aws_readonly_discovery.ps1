<#
Runs read-only AWS CLI discovery against an approved lab account/profile.
Requires enableAwsCommands=true in simulation_config.json.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig

if (-not $Config.enableAwsCommands) {
    throw "AWS commands are disabled. Set enableAwsCommands=true in simulation_config.json after configuring an approved lab AWS profile."
}

$Aws = Get-Command "aws.exe" -ErrorAction SilentlyContinue
if (-not $Aws) {
    $Aws = Get-Command "aws" -ErrorAction SilentlyContinue
}
if (-not $Aws) {
    throw "AWS CLI was not found on this machine."
}

$ProfileArgs = @()
if ($Config.awsProfile) {
    $ProfileArgs += @("--profile", $Config.awsProfile)
}
if ($Config.awsRegion) {
    $ProfileArgs += @("--region", $Config.awsRegion)
}

Write-TrainingStatus "Running read-only AWS discovery."

& $Aws.Source @ProfileArgs sts get-caller-identity
& $Aws.Source @ProfileArgs s3 ls

if ($Config.awsLabBucket) {
    & $Aws.Source @ProfileArgs s3 ls "s3://$($Config.awsLabBucket)"
}

& $Aws.Source @ProfileArgs iam get-account-summary

Write-TrainingStatus "AWS read-only discovery complete."

