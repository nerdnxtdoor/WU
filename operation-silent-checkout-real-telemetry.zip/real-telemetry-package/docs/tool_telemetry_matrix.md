# Tool Telemetry Matrix

## Proofpoint

Expected telemetry:

- Email accepted, delivered, blocked, or quarantined.
- URL defense rewrite and click event.
- Sender, recipient, subject, URL, attachment metadata.
- User-reported phishing event, if the user reports it.

## CrowdStrike Falcon

Expected telemetry:

- Browser process downloads package.
- Explorer launches PowerShell or cmd.
- PowerShell command-line activity.
- Discovery command process tree.
- File creation under `C:\ProgramData\NorthstarTraining`.
- Scheduled task creation.
- HKCU Run key creation.
- Archive creation.
- Browser or PowerShell upload attempt.

## Okta

Expected telemetry:

- Login success/failure.
- MFA challenge and result.
- New device or new location signal, if configured.
- AWS app launch through SSO, if AWS is Okta-integrated.
- Session activity and app access.

## AWS

Expected telemetry:

- CloudTrail records for read-only calls.
- `sts:GetCallerIdentity`.
- S3 list or object read attempts against a lab bucket.
- IAM or EC2 read-only discovery, if permitted.
- AccessDenied events for intentionally restricted actions.

## Netskope

Expected telemetry:

- User visits controlled phishing/training portal.
- File download.
- Access to AWS console or other SaaS apps.
- Upload attempt to approved lab destination.
- DLP or policy match if configured.

