<#
Removes Operation Silent Checkout real-telemetry training artifacts.
#>
[CmdletBinding()]
param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$ConfigPath = Join-Path $ProjectRoot "simulation_config.json"
$Root = "C:\ProgramData\NorthstarTraining"

if (Test-Path $ConfigPath) {
    $Config = Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json
    if ($Config.simulationRoot) {
        $Root = $Config.simulationRoot
    }
}

$TaskName = "NorthstarPayrollUpdater"
$RunKeyPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"

if (-not $Force) {
    $Answer = Read-Host "Remove Northstar training artifacts, scheduled task, and HKCU Run key? Type YES to continue"
    if ($Answer -ne "YES") {
        Write-Host "Cleanup cancelled."
        return
    }
}

if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Removed scheduled task $TaskName."
}

if (Get-ItemProperty -Path $RunKeyPath -Name $TaskName -ErrorAction SilentlyContinue) {
    Remove-ItemProperty -Path $RunKeyPath -Name $TaskName -Force
    Write-Host "Removed Run key $TaskName."
}

if (Test-Path $Root) {
    Remove-Item -Path $Root -Recurse -Force
    Write-Host "Removed $Root."
}

Write-Host "Cleanup complete."

