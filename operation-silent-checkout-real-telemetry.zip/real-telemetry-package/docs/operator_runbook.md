# Operator Runbook

Use this sequence to generate the attack chain one step at a time.

## 1. Configure The Lab

Copy the example config:

```powershell
Copy-Item .\templates\simulation_config.example.json .\simulation_config.json
notepad .\simulation_config.json
```

Set only approved lab values.

## 2. Prepare Fake Data

```powershell
.\scripts\00_prepare_lab.ps1
```

This creates fake finance files, lure files, and a benign updater script under `C:\ProgramData\NorthstarTraining`.

## 3. Send Phishing Email

Use the template in `proofpoint/phishing_email_template.eml`.

Preferred flow:

1. Send from an approved simulation sender.
2. Deliver to the lab user.
3. Include the controlled training URL.
4. Have the user click the URL.
5. Have the user download the package from the controlled page.

## 4. Simulate Initial Execution

```powershell
.\scripts\01_initial_execution.ps1
```

This runs the benign updater from a user context.

## 5. Discovery

```powershell
.\scripts\02_discovery.ps1
```

This runs benign local discovery commands.

## 6. Persistence Simulation

```powershell
.\scripts\03_persistence_sim.ps1 -CreateScheduledTask -CreateRunKey
```

This creates a clearly named scheduled task and HKCU Run key.

## 7. Credential Lure Access

```powershell
.\scripts\04_credential_lure_access.ps1
```

This searches and reads fake credential lure files only.

## 8. Okta Activity

Manually perform:

1. Login as the lab user.
2. Trigger MFA.
3. Launch the AWS app from Okta, if configured.
4. Optionally perform one failed login before a success.

## 9. AWS Read-Only Discovery

```powershell
.\scripts\06_aws_readonly_discovery.ps1
```

This requires AWS CLI and a lab profile or SSO session.

## 10. Stage Fake Finance Data

```powershell
.\scripts\05_stage_finance_data.ps1
```

## 11. Controlled Exfiltration Attempt

```powershell
.\scripts\07_controlled_exfil_attempt.ps1
```

This requires an explicit upload URL or lab S3 bucket in `simulation_config.json`.

## 12. Impact Note

```powershell
.\scripts\08_impact_note.ps1
```

## 13. Cleanup

```powershell
.\cleanup\cleanup_simulation.ps1
```

