# Operation Silent Checkout - Real Telemetry Edition

This package runs a controlled, non-destructive SOC incident response simulation that creates real telemetry in:

- Proofpoint
- CrowdStrike Falcon
- Okta
- AWS CloudTrail
- Netskope
- Your SIEM, if these sources are integrated

The scenario starts with a payroll-themed phishing email and continues through user execution, discovery, persistence simulation, fake credential lure access, Okta/AWS activity, data staging, controlled exfiltration attempt, and harmless impact-note creation.

## Safety Model

This package does not include malware, exploitation, credential theft, destructive behavior, or unauthorized access.

The scripts:

- Run benign local commands.
- Create clearly named training files.
- Create optional, clearly named persistence controls.
- Use fake finance data only.
- Require explicit lab configuration for upload and AWS actions.
- Write only under `C:\ProgramData\NorthstarTraining` by default.

## Best Use

Use a disposable Windows test machine enrolled in CrowdStrike Falcon and routed through Netskope. Use a dedicated Okta test user and a dedicated AWS lab account or sandbox role.

## Quick Start

On the Windows test machine:

```powershell
cd C:\CTF\operation-silent-checkout-real-telemetry
Set-ExecutionPolicy -Scope Process Bypass -Force
Copy-Item .\templates\simulation_config.example.json .\simulation_config.json
notepad .\simulation_config.json
.\scripts\00_prepare_lab.ps1
.\scripts\01_initial_execution.ps1
.\scripts\02_discovery.ps1
.\scripts\03_persistence_sim.ps1 -CreateScheduledTask -CreateRunKey
.\scripts\04_credential_lure_access.ps1
.\scripts\05_stage_finance_data.ps1
.\scripts\06_aws_readonly_discovery.ps1
.\scripts\07_controlled_exfil_attempt.ps1
.\scripts\08_impact_note.ps1
```

Cleanup:

```powershell
.\cleanup\cleanup_simulation.ps1
```

## Important

Do not run the exfiltration or AWS scripts until `simulation_config.json` points to approved lab destinations and identities.

