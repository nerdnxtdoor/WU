<#
Stages and compresses fake finance files.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$FinanceDir = Join-Path $Root "finance_share"
$StagingDir = Join-Path $Root "staging"
$Archive = Join-Path $StagingDir "finance_review_backup.zip"

if (-not (Test-Path $FinanceDir)) {
    throw "Fake finance directory not found. Run 00_prepare_lab.ps1 first."
}

New-TrainingDirectory -Path $StagingDir

Write-TrainingStatus "Copying fake finance files to staging."
Copy-Item -Path (Join-Path $FinanceDir "*") -Destination $StagingDir -Force

if (Test-Path $Archive) {
    Remove-Item -Path $Archive -Force
}

Write-TrainingStatus "Creating archive $Archive."
Compress-Archive -Path (Join-Path $StagingDir "*.csv") -DestinationPath $Archive -Force

Write-TrainingStatus "Data staging complete."

