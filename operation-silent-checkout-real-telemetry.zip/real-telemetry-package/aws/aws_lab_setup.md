# AWS Lab Setup

Use a dedicated AWS sandbox account or tightly scoped lab role.

Recommended permissions for the simulation role:

- `sts:GetCallerIdentity`
- `s3:ListAllMyBuckets`
- `s3:ListBucket` on one lab bucket
- `s3:PutObject` only to a lab prefix, if you want controlled upload telemetry
- `iam:GetAccountSummary`

Example lab bucket/prefix:

```text
s3://northstar-silent-checkout-lab/silent-checkout/
```

Do not use production AWS accounts, production buckets, or production identities.

Set these fields in `simulation_config.json`:

```json
{
  "awsProfile": "northstar-training",
  "awsRegion": "us-east-1",
  "awsLabBucket": "northstar-silent-checkout-lab",
  "enableAwsCommands": true,
  "enableUpload": true
}
```

