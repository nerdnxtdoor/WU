function Get-SimulationConfig {
    $ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
    $ConfigPath = Join-Path $ProjectRoot "simulation_config.json"
    $ExamplePath = Join-Path $ProjectRoot "templates\simulation_config.example.json"

    if (-not (Test-Path $ConfigPath)) {
        Copy-Item -Path $ExamplePath -Destination $ConfigPath -Force
        Write-Host "[Northstar Training] Created simulation_config.json from template. Review it before AWS or upload steps."
    }

    $Config = Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json
    if (-not $Config.simulationRoot) {
        $Config | Add-Member -NotePropertyName simulationRoot -NotePropertyValue "C:\ProgramData\NorthstarTraining"
    }
    return $Config
}

function Get-SimulationRoot {
    param([object]$Config)
    return $Config.simulationRoot
}

function New-TrainingDirectory {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Force -Path $Path | Out-Null
    }
}

function Write-TrainingStatus {
    param([string]$Message)
    Write-Host "[Northstar Training] $Message"
}

