<#
Creates a harmless training note. Does not encrypt, delete, or modify existing user files.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$Note = Join-Path $Root "READ_ME_TRAINING.txt"

@"
Northstar Market security training simulation.

This is a harmless impact-note simulation.
No files were encrypted, deleted, overwritten, or damaged.

Cleanup:
.\cleanup\cleanup_simulation.ps1
"@ | Out-File -FilePath $Note -Encoding utf8

Write-TrainingStatus "Harmless impact note created at $Note."

