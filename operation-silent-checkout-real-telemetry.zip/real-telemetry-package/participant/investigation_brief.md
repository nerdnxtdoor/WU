# Participant Investigation Brief

Northstar Market received alerts involving a finance user, a payroll-themed email, endpoint script execution, unusual identity activity, AWS read-only discovery, and a possible upload attempt.

Your objectives:

- Identify the initial access vector.
- Determine who clicked the phishing link.
- Identify the affected endpoint.
- Reconstruct the endpoint process tree.
- Identify discovery commands.
- Identify persistence mechanisms.
- Determine whether credentials were accessed.
- Review Okta and AWS activity.
- Determine whether fake finance data was staged.
- Determine whether exfiltration was attempted, allowed, or blocked.
- Recommend containment, eradication, recovery, and detection improvements.

