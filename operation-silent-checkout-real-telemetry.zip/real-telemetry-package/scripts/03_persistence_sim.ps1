<#
Creates clearly named, removable persistence simulation controls.
#>
[CmdletBinding()]
param(
    [switch]$CreateScheduledTask,
    [switch]$CreateRunKey
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$Config = Get-SimulationConfig
$Root = Get-SimulationRoot -Config $Config
$TaskName = "NorthstarPayrollUpdater"
$RunKeyPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$Heartbeat = Join-Path $Root "payload\training_heartbeat.ps1"

New-TrainingDirectory -Path (Split-Path $Heartbeat -Parent)

@'
[CmdletBinding()]
param()
Write-Host "Northstar payroll updater training heartbeat."
'@ | Out-File -FilePath $Heartbeat -Encoding utf8

if ($CreateScheduledTask) {
    Write-TrainingStatus "Creating scheduled task $TaskName."
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$Heartbeat`""
    $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(30)
    Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Description "Northstar SOC training simulation; safe to remove." -Force | Out-Null
}

if ($CreateRunKey) {
    Write-TrainingStatus "Creating HKCU Run key $TaskName."
    New-ItemProperty -Path $RunKeyPath -Name $TaskName -Value "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$Heartbeat`"" -PropertyType String -Force | Out-Null
}

if (-not $CreateScheduledTask -and -not $CreateRunKey) {
    Write-TrainingStatus "No persistence option selected. Re-run with -CreateScheduledTask and/or -CreateRunKey."
}

Write-TrainingStatus "Persistence simulation step complete."

