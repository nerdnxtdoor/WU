<#
Benign payroll updater lure for Operation Silent Checkout.
This creates real endpoint telemetry without malicious behavior.
#>
[CmdletBinding()]
param()

$Root = "C:\ProgramData\NorthstarTraining"
New-Item -ItemType Directory -Force -Path $Root | Out-Null
"Payroll update validation executed at $(Get-Date -Format o) by $env:USERNAME on $env:COMPUTERNAME" |
    Out-File -FilePath (Join-Path $Root "payroll_update_execution.txt") -Encoding utf8
whoami | Out-Null
hostname | Out-Null
Write-Host "Payroll update validation complete."

